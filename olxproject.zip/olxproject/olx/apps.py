from django.apps import AppConfig


class OlxConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'olx'
